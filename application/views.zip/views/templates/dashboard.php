<?php echo $header;?>

<?php echo $leftmenu;?>
      <!-- Content Wrapper. Contains page content -->
    <div class="content-wrapper">
        <?php echo $content;?>
    </div><!-- /.content-wrapper -->
     
<?php echo $footer;?>