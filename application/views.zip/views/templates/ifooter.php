 <script src="https://cdn.jsdelivr.net/jquery.slick/1.3.15/slick.min.js"></script>

    <script src="<?=base_url()?>assets/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- Main JS -->
    <script src="<?=base_url()?>assets/js/main1.js"></script>
</body>

</html>