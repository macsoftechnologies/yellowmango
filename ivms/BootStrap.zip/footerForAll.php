<?php {?>

<link rel="stylesheet" type="text/css" href="footer.css"> 


	<div class = "footer">
		
	<span > 2020 © SHYAM INFOTECH
	</span>


	</div>




<?php }?>