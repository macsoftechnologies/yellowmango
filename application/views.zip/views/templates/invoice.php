<?php echo $header;?>



    <?php echo $content;?>

     

<?php echo $footer;?>