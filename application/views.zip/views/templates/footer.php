 <footer class="footer">
            <div class="container-fluid clearfix">
              <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright &copy; <?php echo date('Y');?></span>
              <!-- <strong>Copyright &copy; <?php echo date('Y');?> <a href="http://macsof.com" target="_blank">MacsOf Technologies</a></strong> -->
              <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">  <a href="http://macsof.com" target="_blank">MacsOf Technologies</a></span>
            </div>
          </footer>
          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>

    <script src="<?=base_url();?>assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <!-- <script src="<?=base_url();?>assets/js/off-canvas.js"></script> -->
    <!-- <script src="<?=base_url();?>assets/js/hoverable-collapse.js"></script> -->
    <script src="<?=base_url();?>assets/js/misc.js"></script>
   
  </body>
</html>