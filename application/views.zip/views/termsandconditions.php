  <script type="text/javascript">
            var baseurl = "<?php echo base_url();?>";
        </script>

 <style type="text/css">
     .closedd { 
        text-align: center;
        font-size: 30px;
        font-weight: bold;
        line-height: 1;
        color: #000;
        text-shadow: 0 1px 0 #fff;
        opacity: 0.4;
      }

      .add-cart h3 {
            color: red;
         }

         .para h3 {
            color: red;
         }
 </style>       
  <script type="text/javascript">
            var baseurl = "<?php echo base_url();?>";
        </script>
        <style>
        .col-md-7 {
            max-width: 700px !important;
        }

        .col-md-5 {
            max-width: 500px !important;
        }

        @media (max-width: 768px) {
            .col-md-7 {
                padding: 0px
            }

            .col-md-5 {
                padding: 0px
            }
        }

    .payment { 
        font-size: 20px;
     }
     .radios { 
        width: 15px;
      }
}
    </style>





<div class="">
    <div class="banner-header check_banner banner-lbook3 banner-background2">
                <div class="overlay"></div>
                <!-- <img src="<?=base_url();?>assets2/images/banner_images/small-banner.jpg" alt="Banner-header"> -->
                <div class="text">
                    <h3>Terms and Conditions</h3>
                    <!-- <p><a href="#" title="Home">Home</a><i class="fa fa-caret-right"></i><a href="#" title="Home">Product Details</a><i class="fa fa-caret-right"></i>Daisy Coffee Table</p> -->
                </div>
            </div>
</div>

<div class="container">
    <div class="col-md-12">
        <div class="row">
            <!-- <div class="col-md-2">
                
            </div> -->

            <div class="col-md-12">
                <div class="terms-content">
                    <p>Terms &amp; Conditions of Use These Terms and Conditions govern your use of the Veera Import and Export website (www.Veera Import and Export.com.sg) and your relationship with Veera Import and Export International Pte Ltd (&quot;we&quot;, &quot;us&quot;, &quot;our&quot;, the &quot;Website&quot;, &ldquo;Veera Import and Export&rdquo;). We welcome customers to browse and compare prices. It is important that you go through the policies and understand them before registration. This set of Terms and Conditions will help you understand how Veera Import and Export operates and ensures that we serve you fairly and properly. Only registered and approved customers are able to place orders through Veera Import and Export website.</p>

                    <h4>Introduction</h4>

                    <p>These Terms and Conditions apply to any orders and purchases made on Veera Import and Export. We reserve the right to amend/update these Terms and Conditions at our sole discretion without notice to the Customer.</p>

                    <h4>Registration and Passwords</h4>

                    <p>Registration provides a unique identification for each shopper and helps us to trace all orders in cases where there are queries or problems.</p>

                    <p>Registration is simple and done only by an individual shopper. The shopper must provide a unique email and password. The email and password will be required for login to Veera Import and Export.</p>

                    <p>Customers must be over 18 years of age to register. Customers must also ensure that all details provided during registration or any other time are correct and complete. Any changes to details provided during registration must be updated by informing Veera Import and Export or via our website.</p>

                    <p>You will be asked to provide a Password upon registration, this Password must be kept confidential and must not be disclosed or shared with anyone. You will be responsible for any purchases and activities that are submitted under this Password.</p>

                    <p>Veera Import and Export reserves the right to refuse, suspend or terminate registration of individual and corporate member immediately at our discretion and not limited to following:</p>

                    <ul>
                        <li>1. Dormant Customers</li>
                        <li>2. Multiple accounts delivering to same delivery details</li>
                    </ul>

                    <h4>Personal Data Protection Act 2012</h4>

                    <ul>
                        <li>
                            1. In connection with the Personal Data Protection Act 2012 (PDPA), you agree that Veera Import and Export International Pte Ltd and its related or affiliated organisations (hereafter collectively referred to as &quot;Veera Import and Export&quot;, &quot;we&quot;, &quot;us&quot; or &quot;our&quot;) may collect, use, process, disclose, and/or transfer your personal data for the purposes of administering, maintaining and terminating your membership and keeping you informed of updates, changes and the scope of which may include but is not limited to:
                            

                            <ul>
                                <li><span>1.</span> administering and maintaining your account with us, including administering any benefits and entitlements;</li>
                                <li><span>3.</span>Engaging third party service providers to perform certain aspects of the services offered;</li>
                                <li><span>3.</span> Unless you notify us that you do not wish to receive such information, sending you information from time to time through e-mail and post about products and services, promotions and special offers, upcoming events and other information which may be of interest to you;</li>
                                <li><span>4.</span> customer profiling, market analysis and research purposes to improve our product and service offerings to you; </li>
                                <li><span>5.</span> notifying you about important changes to the membership program; responding to queries or feedback from you; </li>
                                <li><span>6.</span> enforcing these Terms and Conditions and our legal rights and remedies; and for such other purposes as permitted by applicable law or with your consent. </li>
                                <li><span>7.</span> In compliance with the PDPA, Veera Import and Export will not send marketing messages to Singapore mobile numbers belonging to you unless you have given us clear and unambiguous consent to do so. If you have previously given us consent, we will continue to send you marketing messages until you advise us in writing that you wish to withdraw the consent. Intellectual Property</li>
                            </ul>                    
                        </li>

                        <li>2.You acknowledge that the Veera Import and Export website contains information, data, software, photographs, graphics, typefaces, music, sounds and other material (collectively &quot;content&quot;) that are protected by copyrights, trademarks, database and other intellectual property rights owned by us or our suppliers.</li>
                    </ul>

                    <p>You may not modify, reproduce, copy or distribute any of the content on Veera Import and Export for commercial purposes without our prior consent.</p>

                    <h4>Use of the Website</h4>

                    <p>You may not use Veera Import and Export for any of the following purposes:</p>

                    <ul>
                        <li><span>1.</span> Disseminating any unlawful, harassing, libelous, abusive, threatening, harmful, vulgar, obscene, or otherwise objectionable material</li>

                        <li><span>2.</span>  Transmitting material that encourages conduct that constitutes a criminal offence or results in civil liability or otherwise breaches any relevant laws, regulations or code of practice</li>

                        <li><span>3.</span> Gaining unauthorised access to other computer systems Interfering with any other person's use of the website Interfering or disrupting networks or web sites connected to the website Making, transmitting or storing electronic copies of materials protected by copyright without the permission of Veera Import and Export. Promotion Terms &amp; Conditions</li>
                    </ul>

                    <p>In the event of suspected fraud or misuse, Veera Import and Export reserves the right to reject or cancel the use of a promo code. We also reserve the right to charge you partially or in full the value of the benefit received, using your order payment method, without further notice.</p>

                    <h4>Website Availability</h4>

                    <p>Whilst all attempts will be made to ensure Veera Import and Export website access is available all the time, occasionally the Site may undergo repairs, maintenance or the introduction of new services. Veera Import and Export website include links to other websites or materials which are beyond its control.</p>

                    <h4>Corporate Members Registration</h4>

                    <p>Customers representing their companies/institutions can sign up under the &quot;Corporate Register&quot; button on our homepage.</p>

                    <p>Orders made through a corporate account shall be delivered strictly to a corporate address. Any corporate orders placed for delivery to either a non-registered company address or a residential address will not be processed.</p>

                    <h4>Pricing and Product Information</h4>

                    <p>Whilst every effort is made to fulfill orders in terms of price, details and size through the Veera Import and Export website, Veera Import and Export expressly reserves the right to vary the price and other details of the Products without notice. Fresh produce may vary from photo as fresh, natural products are never identical even when they are from the same variety and supplier. As much as Veera Import and Export tries to reflect the actual Product size, details and price, Veera Import and Export is not liable for situation when they differ from the actual Product.</p>

                    <p>In the event of any price differentials between the online order billing and the final bill whether arising from substitutions, daily price changes, out-of-stock Products, special price, mislabeling or mis-pricing etc, Veera Import and Export reserves the right to adjust the final bill after the online bill is presented/conveyed to the Customer and such adjustment shall be final.</p>

                    <p>Veera Import and Export has made every effort to display the colours of our Products that appear on the Website as accurately as possible. However, as the actual colours you see will depend on your monitor, we cannot guarantee that your monitor's display of any colour will be accurate.</p>

                    <p>Veera Import and Export shall not be liable to any Customer/person for any loss, damage incurred or inconvenience suffered in the event Veera Import and Export declines to fulfill an order for whatever reason including but not limited to an unforeseen circumstance (e.g. lack of availability, quantity or specification etc) as the case may be.</p>

                    <h4>Product Unavailability</h4>

                    <p>In situations of stock unavailability for any item(s) in an Order placed with Veera Import and Export, we reserve the right to process the other items listed in the Order. This is because, at Veera Import and Export, we work towards bringing you a wholesome online experience. If any item you have ordered is not in this confirmation, it is with much regret to inform you that it is unavailable. Special offers are valid while stock last. Veera Import and Export reserves the right to reject, and/or limit quantities on any orders received.</p>

                    <h4>Refunds</h4>

                    <p>We ask that you check your order upon delivery. If you&rsquo;re not completely happy with your fresh or perishable products, let us know within 24 hours from your delivery date and we&rsquo;ll give you a refund. If there is any damaged or incorrect grocery product(s) (including delivery of additional product(s) not ordered by you), please contact us within 24 hours of your delivery date at hello@Veera Import and Export.com.sg with photographs of the unsatisfactory items. Veera Import and Export at its sole discretion, will offer a refund of the damaged or incorrect product(s). The refunds will be offered as non-monetary refunds, for example, in the form of discount vouchers or its equivalent.</p>

                    <p>Only order cancellations will have full monetary refunds subject to cancellation charges where applicable.</p>

                    <p>Delivery/Order Amendment</p>

                    <p>The general terms and conditions for all deliveries are as follows:</p>

                    <ul>
                        <li><span>1.</span> Delivery date and time are subjected to availability. Delivery service is only available in the main island of Singapore. It is not available to Jurong Island, restricted areas (eg. military camps) and any of the outlying islands.</li>

                        <li><span>2.</span> Veera Import and Export will only deliver your order to the front door at the stated delivery address. Customer needs to be present to receive the delivered items.</li>

                        <li><span>3.</span> Customers who wish to have their purchases left outside the home, Veera Import and Export shall not be liable for any consequential, indirect or special damages or loss of whatever descriptions. For all normal orders, there is a cancellation charge of $20 (excl. GST).</li>

                        <li><span>4.</span> For all bulk orders, there is a cancellation charge of $30 (excl. GST). All prices listed are in Singapore Dollars. For any enquiries, please contact our Veera Import and Export Team at email hello@Veera Import and Export.com.sg If there are any changes in the delivery address / contact details made between submission of order and delivery date, customers are to update Veera Import and Export at least 48 hours prior to delivery. Should delay of delivery date and time be required, the order will be subjected to a surcharge of $4 (exclusive of GST). Requests for a delay in delivery date and time for bulk orders will be subjected to a surcharge of $30 (exclusive of GST).</li>
                    </ul>

                    <p>No amendment to an order is allowed once order is processed. To add items, kindly create a 2nd order within 48 hours prior to delivery and inform us via email hello@Veera Import and Export.com.sg.</p>

                    <p>All amendments if agreed to surcharge or cancellation of deliveries must be confirmed via a reply through email.</p>

                    <h4>Order Cancellation</h4>

                    <p>The Customer may cancel the order up to the point in time via email before Veera Import and Export processes the order. After which, there would be a cancellation charge of $20 (exclusive of GST) for Home Delivery and $30 (exclusive of GST) for Bulk Order Delivery imposed for each order cancelled.</p>

                    <p>No cancellation charges will be imposed if customer provides us with the cancellation or amendment details at least 3 days prior to the agreed delivery timing (except for special bulk order arrangement).</p>

                    <h4>Payment</h4>

                    <p>Payment information is transmitted through a secure payment channel using our secure server and Secure Socket Layer (SSL). Once payment mode has been selected and order has been submitted, any changes on payment mode is not possible.</p>

                    <p>If corporate cheque require more lead time to issue, customers are to choose appropriate delivery dates or inform Veera Import and Export within sufficient time frame of processing the order. We reserve rights to delay order or charge re delivery of $7 (inclusive of GST) if cheque is not ready upon delivery.</p>

                    <p>Veera Import and Export reserves the right to change the mode or method of payment for Products offered online at any time by announcement via its website, email blasts and any other means of public communications.</p>

                    <h4>Links</h4>

                    <p>Veera Import and Export is not responsible for content of any other sites outside the Veera Import and Export Website. In addition, a link to another website does not mean that Veera Import and Export endorses or accepts any responsibility for the content displayed on the other website.</p>

                    <h4>Warranties</h4>

                    <p>Veera Import and Export expressly excludes all warranties, descriptions, representations or advice rendered as to the fitness or suitability for any purpose, tolerance to any conditions, similarity to sample, merchantability or otherwise of the Product supplied to the fullest extent permitted by law.</p>

                    <p>No Agent or representative of Veera Import and Export is authorised to make any warranty, representation or statements given as to the fitness or suitability for any purpose, tolerance to any condition, similarity to sample, merchantability or otherwise of the Product supplied.</p>

                    <h4>Limitation of Liabilities</h4>

                    <p>Veera Import and Export shall not liable for any consequential, indirect or special damages or loss of whatever descriptions. To the extent that Veera Import and Export is liable in contract, tort or otherwise for any loss, damage or injury arising directly or indirectly from any defect in or or non-compliance of the Product or any other breach of Veera Import and Export's obligations here under, such liability shall not in any event exceed an amount equivalent to the price of the Product(s).</p>

                    <p>Both Veera Import and Export and the delivery company will not be held responsible for any damages or loss of Products after delivery. The Customer shall not use the Product in any manner and/or for any purpose for which they are unsuited for and shall be responsible for using all necessary skill and care in handling and using the Product. The Customer expressly agrees that Veera Import and Export assumes no obligation or liability for any advice or information given with the Products and Veera Import and Export assumes no responsibility for any inaccuracy or misstatement of any such information. The Customer assumes all risks connected with the use and storage of the Product.</p>

                    <p>Customer unreservedly acknowledges and agrees that he/she assumes all risk in connection with the use of this site. Veera Import and Export shall not be liable for any direct, indirect, consequential or punitive damage or loss of profits or loss of revenue however arising from the use of, access to the site. Without limitation to the foregoing:</p>

                    <p>This site and all information contained herein is provided on a &quot;as is&quot; without any implied or express warranty including of any implied warranty as to title, quality, merchantability, fitness for purpose, or non-infringement. Before acting on the information found on Veera Import and Export website, you may wish to confirm the facts that are important to your decision making. Product information on our website may be different from information on the products for a variety of reasons including such things as manufacturers&rsquo; updates and changes. Veera Import and Export reserves the right to change or update information on any product on Veera Import and Export at any time without prior notice.</p>

                    <p>To the fullest extent permitted by law, Veera Import and Export shall not be liable for any error or omission in the content of the site including any damage or injury arising out of or in connection with any access or use of the site whether such damage/injury is caused by failure of performance, error, omission, defect, delay in operation, computer virus, theft etc.</p>

                    <h4>Colours</h4>

                    <p>Veera Import and Export take great care to accurately display the colours of our products that appear on its website. However, we cannot guarantee that your monitor&rsquo;s display of any colour will be as accurate as the actual product colour.</p>

                    <h4>Third Party Sites</h4>

                    <p>There may be occasions when materials on or of third Parties are provided on Veera Import and Export website. Veera Import and Export is not responsible for the content and activities of any third party site linked from and beyond Veera Import and Export site. Your visit or use of any third party site linked from Veera Import and Export is entirely at your own risk.</p>

                    <h4>Promotional Codes</h4>

                    <p>Promotional codes are valid for a limited or specified period only and Veera Import and Export reserves the right to modify, cancel or discontinue them at any time on the Veera Import and Export website, without any notice. Promotional codes are not transferable and not redeemable for cash. Each promotional code has its own qualifying terms. It is void where prohibited by law. All offers are subject to availability and while stock lasts.</p>

                    <h4>The general terms and conditions for all promotions are as follows:</h4>

                    <ul>
                        <li><span>1.</span> Promo code cannot be used with any other available promo codes. Veera Import and Export reserves the right to reject any order that has violated this. Redemption of promo code is applicable to purchases made on Veera Import and Export website.</li>

                        <li><span>2.</span> Using a promo code discount in conjunction with other free gift promotions may alter the minimum amount criteria for it. Please check your cart to ensure promo code discount is applied and review your order carefully before checkout. Discount, vouchers and privileges are not exchangeable for cash, kind or other goods and services. All prices listed are in Singapore Dollars.</li>

                        <li><span>3.</span> There is a bulk order charge of $25 (excl. GST) for every order with more than 50 items purchased. If the subtotal/ cart amount is $35 or above after applying the discount promo code, the order will qualify for free delivery. Otherwise, home delivery fee will still apply.</li>

                        <li><span>4.</span> Veera Import and Export reserves the rights to vary/amend the privileges or terms and conditions of all promotions without prior notice. For any enquiries, please contact our Veera Import and Export Team at email hello@Veera Import and Export.com.sg Veera Import and Export shall not be liable to any Customer for any financial loss arising out of the refusal, cancellation or withdrawal of any order for any reason.</li>
                    </ul>

                    <h4>Governing Law and Jurisdiction</h4>

                    <p>These Terms and Conditions shall be construed in accordance with the applicable laws of Singapore. Both the Customer and Veera Import and Export irrevocably and unconditionally submit to the non-exclusive jurisdiction of the courts of Singapore.</p>

                    <h4>Termination</h4>

                    <p>If you violate any of these Terms and Conditions, your permission to use the Website may be suspended or revoked, and we reserve the right to suspend or terminate your access to, and use of, the Website at any time.</p>

                    <h4>Miscellaneous</h4>

                    <p>No orders via phone or email will be accepted, all customers have to register for an account and submit their orders online via the website.</p>

                    <h4>Veera Import and Export cannot be held responsible for any inaccuracy or omission. Veera Import and Export will attempt its best to fulfill orders placed by shoppers. In the event that an ordered Product is not available, Veera Import and Export reserves the right not to replace it with a similar item of equivalent value.</h4>

                    <p>Customers are strongly advised to check the item purchased at the time of acceptance to avoid any possible dispute. All Products leaving our distribution center have been checked for quality and accurate quantity. However, we will replace any defective Products that do not meet our customers' expectation.</p>
                </div>
            </div>
        </div>
    </div>
</div>

    <script type="text/javascript">
    var baseurl = "<?php echo base_url();?>";
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"> </script>
<script type="text/javascript">
    $(document).ready(function(){
        $('body').on('click', '.cart_id', function(){
          var id = $(this).attr('id');
          var url = baseurl+'home/deleteCart';
          $.ajax({
              url: url,
              type: 'POST',
              dataType: 'json',
              data:{cart_id:id},
              success: function (res) {
                  if(res['status'] == "pass")
                  {
                    location.reload();
                  }
                  else
                  {
                     alert("somethig went wrong");
                     location.reload();
                  }
              }
          });
      })
    });
</script>

    <script type="text/javascript">
//      $(document).ready(function(){
//      $('.quantity').change(function(){
//           var itemId = $(this).attr('id');
//           var aa = itemId.split("_");
//           var qty = $('#quantity_'+aa[1]).val();
//           var url = baseurl+'home/changeQuantity';
//               $.ajax({
//                   url: url,
//                   type: 'POST',
//                   dataType: 'json',
//                   data:{cart_id : aa[1], quantity:qty},
//                   success: function (res) {
//                       console.log(res['status']);
//                       if(res['status'] == "pass")
//                       {
//                           location.reload();
//                       }
//                       else
//                       {
//                          alert("smothig went wrong");
//                          location.reload();
//                       }
//                   }
//               });
//         });
//   });
// </script> 

<script>
    window.onscroll = function() {myFunction()};
    var headerTop = document.getElementById("header-top");
    function myFunction() {
        if(window.innerWidth > 1200) {
            if (window.scrollY > 100) {
    headerTop.classList.add("fixed-header");
  } else {
    headerTop.classList.remove("fixed-header");
  }
        }
  
}
</script>