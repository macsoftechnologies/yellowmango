<?php 
ob_start();
session_start();

$conn = mysqli_connect("localhost","root","") or die("Error in establishing database connection");
$db = mysqli_select_db($conn,"logistic");
?>